`descriptor:command2`
---------------------

command 2 description

### Usage

* `descriptor:command2 [-o|--option_name] [--] <argument_name>`
* `descriptor:command2 -o|--option_name <argument_name>`
* `descriptor:command2 <argument_name>`

command 2 help

### Arguments

#### `argument_name`

* Is required: yes
* Is array: no
* Default: `NULL`

### Options

#### `--option_name|-o`

* Accept value: no
* Is value required: no
* Is multiple: no
* Default: `false`
